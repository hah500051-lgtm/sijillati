import { ChevronLeft, ChevronRight, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatGregorianLong } from "@/lib/date";

type DateNavigatorProps = {
  value: string;
  onChange: (iso: string) => void;
  label?: string;
};

function shiftDay(iso: string, delta: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  date.setDate(date.getDate() + delta);
  const yy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}

export default function DateNavigator({ value, onChange, label }: DateNavigatorProps) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-teal-100 bg-teal-50/60 px-4 py-3">
      <div className="flex items-center gap-2 text-teal-800">
        <CalendarDays className="h-5 w-5" />
        <span className="text-sm font-medium">{label ?? "التاريخ"}</span>
      </div>

      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="icon"
          aria-label="اليوم السابق"
          onClick={() => onChange(shiftDay(value, -1))}
          className="border-teal-200 bg-white text-teal-700 hover:bg-teal-100"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>

        <div className="min-w-40 rounded-xl border border-teal-200 bg-white px-4 py-2 text-center">
          <p className="text-sm font-semibold text-slate-800">{formatGregorianLong(value)}</p>
        </div>

        <Button
          type="button"
          variant="outline"
          size="icon"
          aria-label="اليوم التالي"
          onClick={() => onChange(shiftDay(value, 1))}
          className="border-teal-200 bg-white text-teal-700 hover:bg-teal-100"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}