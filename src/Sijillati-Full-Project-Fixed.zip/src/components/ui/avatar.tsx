import * as React from 'react'; import * as A from '@radix-ui/react-avatar'; import {cn} from '@/lib/utils';
export const Avatar=({className,...p}:React.ComponentProps<typeof A.Root>)=><A.Root className={cn('relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full',className)} {...p}/>;
export const AvatarFallback=({className,...p}:React.ComponentProps<typeof A.Fallback>)=><A.Fallback className={cn('flex h-full w-full items-center justify-center rounded-full bg-slate-100 font-medium',className)} {...p}/>;
