import * as React from 'react'; import {cn} from '@/lib/utils';
export function Badge({className,...p}:React.HTMLAttributes<HTMLDivElement>){return <div className={cn('inline-flex items-center rounded-full border border-transparent bg-teal-50 px-2.5 py-0.5 text-xs font-semibold text-teal-800',className)} {...p}/>}
