import * as React from 'react'; import {cn} from '@/lib/utils';
export const Table=({className,...p}:React.TableHTMLAttributes<HTMLTableElement>)=><div className="relative w-full overflow-auto"><table className={cn('w-full caption-bottom text-sm',className)} {...p}/></div>;
export const TableHeader=({className,...p}:React.HTMLAttributes<HTMLTableSectionElement>)=><thead className={cn('[&_tr]:border-b bg-slate-50',className)} {...p}/>;
export const TableBody=({className,...p}:React.HTMLAttributes<HTMLTableSectionElement>)=><tbody className={cn('[&_tr:last-child]:border-0',className)} {...p}/>;
export const TableRow=({className,...p}:React.HTMLAttributes<HTMLTableRowElement>)=><tr className={cn('border-b transition-colors hover:bg-slate-50/70',className)} {...p}/>;
export const TableHead=({className,...p}:React.ThHTMLAttributes<HTMLTableCellElement>)=><th className={cn('h-11 px-3 text-right align-middle font-medium text-slate-600',className)} {...p}/>;
export const TableCell=({className,...p}:React.TdHTMLAttributes<HTMLTableCellElement>)=><td className={cn('p-3 align-middle',className)} {...p}/>;
