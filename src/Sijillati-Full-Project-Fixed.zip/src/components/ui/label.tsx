import * as React from 'react'; import {cn} from '@/lib/utils';
export const Label=({className,...p}:React.LabelHTMLAttributes<HTMLLabelElement>)=><label className={cn('text-sm font-medium leading-none text-slate-700',className)} {...p}/>;
