import { useEffect, useState } from "react";
import { Save, School, UserRound, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export type Settings = {
  teacherName: string;
  schoolName: string;
};

const STORAGE_KEY = "sijli-settings";

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<Settings>;
      return {
        teacherName: parsed.teacherName ?? "",
        schoolName: parsed.schoolName ?? "",
      };
    }
  } catch {
    /* ignore */
  }
  return { teacherName: "", schoolName: "" };
}

export function saveSettings(settings: Settings) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    /* ignore */
  }
}

type SettingsPanelProps = {
  settings: Settings;
  onSave: (settings: Settings) => void;
};

export default function SettingsPanel({ settings, onSave }: SettingsPanelProps) {
  const [teacherName, setTeacherName] = useState(settings.teacherName);
  const [schoolName, setSchoolName] = useState(settings.schoolName);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setTeacherName(settings.teacherName);
    setSchoolName(settings.schoolName);
  }, [settings.teacherName, settings.schoolName]);

  const handleSave = () => {
    onSave({ teacherName: teacherName.trim(), schoolName: schoolName.trim() });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };

  return (
    <Card className="rounded-2xl border-teal-100 shadow-sm">
      <CardHeader className="border-b border-teal-100 bg-teal-50/60">
        <CardTitle className="font-serif text-xl text-teal-900">الإعدادات</CardTitle>
        <CardDescription className="text-teal-700/80">
          بيانات المدرس والمدرسة تُحفظ في هذا المتصفح وتظهر في التقرير.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6 p-6">
        <div className="space-y-2">
          <Label htmlFor="teacherName" className="flex items-center gap-2 text-slate-700">
            <UserRound className="h-4 w-4 text-teal-600" />
            اسم المدرس
          </Label>
          <Input
            id="teacherName"
            value={teacherName}
            onChange={(e) => setTeacherName(e.target.value)}
            placeholder="مثال: أ. محمد العتيبي"
            className="border-slate-200 bg-white"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="schoolName" className="flex items-center gap-2 text-slate-700">
            <School className="h-4 w-4 text-teal-600" />
            اسم المدرسة
          </Label>
          <Input
            id="schoolName"
            value={schoolName}
            onChange={(e) => setSchoolName(e.target.value)}
            placeholder="مثال: مدرسة النور الثانوية"
            className="border-slate-200 bg-white"
          />
        </div>

        <div className="flex items-center gap-3">
          <Button
            type="button"
            onClick={handleSave}
            className="bg-teal-700 text-white hover:bg-teal-800"
          >
            <Save className="h-4 w-4" />
            حفظ البيانات
          </Button>

          {saved && (
            <span className="flex items-center gap-1 text-sm font-medium text-emerald-600">
              <CheckCircle2 className="h-4 w-4" />
              تم حفظ البيانات
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}