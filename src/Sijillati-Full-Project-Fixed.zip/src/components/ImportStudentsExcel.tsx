import { useRef, useState } from "react";
import { FileSpreadsheet, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

type Props = {
  onImport: (names: string[]) => void;
  triggerLabel?: string;
  triggerClassName?: string;
};

function parseCsv(text: string): string[] {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  const names: string[] = [];
  lines.forEach((line, index) => {
    const cells = line.split(/[,;\t]/).map((c) => c.replace(/^"|"$/g, "").trim());
    const first = cells.find((c) => c.length > 0 && !/^\d+$/.test(c));
    if (!first) return;
    if (index === 0 && /اسم|الطالب|name/i.test(first)) return;
    names.push(first.replace(/^\s*\d+[).\-:]?\s*/, "").trim());
  });
  return names.filter((n) => n.length > 0);
}

export default function ImportStudentsExcel({ onImport, triggerLabel, triggerClassName }: Props) {
  const [open, setOpen] = useState(false);
  const [names, setNames] = useState<string[]>([]);
  const [fileName, setFileName] = useState("");
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  function reset() {
    setNames([]);
    setFileName("");
    setError("");
    if (inputRef.current) inputRef.current.value = "";
  }

  function handleFile(file: File | undefined) {
    if (!file) return;
    setFileName(file.name);
    setError("");
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result ?? "");
      const parsed = parseCsv(text);
      if (parsed.length === 0) {
        setNames([]);
        setError("لم يتم العثور على أسماء في الملف. تأكد أن الأسماء في العمود الأول.");
        return;
      }
      setNames(parsed);
    };
    reader.onerror = () => setError("تعذّر قراءة الملف. حاول مرة أخرى.");
    reader.readAsText(file, "utf-8");
  }

  function submit() {
    if (names.length === 0) return;
    onImport(names);
    reset();
    setOpen(false);
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) reset();
      }}
    >
      <DialogTrigger asChild>
        <Button variant="outline" className={triggerClassName}>
          <FileSpreadsheet className="ml-1 h-4 w-4" />
          {triggerLabel ?? "استيراد الطلبة من الإكسل"}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-serif text-xl">
            <FileSpreadsheet className="h-5 w-5 text-teal-600" />
            استيراد الطلبة من الإكسل
          </DialogTitle>
          <DialogDescription>
            ارفع ملف CSV / Excel مُصدَّرًا كنص، بحيث يحتوي العمود الأول على أسماء الطلاب.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-2">
            <Label htmlFor="excel-file">ملف الأسماء</Label>
            <input
              id="excel-file"
              ref={inputRef}
              type="file"
              accept=".csv,.txt,.tsv,text/csv"
              onChange={(e) => handleFile(e.target.files?.[0])}
              className="block w-full cursor-pointer rounded-lg border border-dashed border-slate-300 bg-slate-50 p-3 text-sm text-slate-600 file:ml-2 file:rounded-md file:border-0 file:bg-teal-600 file:px-3 file:py-1.5 file:text-white hover:border-teal-300"
            />
          </div>

          {fileName && (
            <p className="text-xs text-slate-500">
              الملف: <span className="font-medium text-slate-700">{fileName}</span>
            </p>
          )}

          {error && (
            <p className="rounded-lg border border-rose-100 bg-rose-50 p-3 text-xs text-rose-700">
              {error}
            </p>
          )}

          {names.length > 0 && (
            <div className="rounded-lg border border-teal-100 bg-teal-50 p-3">
              <p className="text-xs font-medium text-teal-800">
                تم العثور على {names.length} طالبًا:
              </p>
              <ul className="mt-2 max-h-32 space-y-1 overflow-y-auto text-xs text-teal-900">
                {names.slice(0, 50).map((n, i) => (
                  <li key={`${n}-${i}`} className="flex items-center gap-2">
                    <Upload className="h-3 w-3 opacity-60" />
                    {n}
                  </li>
                ))}
                {names.length > 50 && <li className="opacity-70">… و {names.length - 50} آخرين</li>}
              </ul>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => setOpen(false)}>
            إلغاء
          </Button>
          <Button
            onClick={submit}
            disabled={names.length === 0}
            className="bg-teal-600 hover:bg-teal-700"
          >
            استيراد {names.length > 0 ? `(${names.length})` : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}