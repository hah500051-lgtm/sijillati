import { useState } from "react";
import { ClipboardList, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

type Props = {
  onAdd: (names: string[]) => void;
  triggerLabel?: string;
  triggerClassName?: string;
};

export default function BulkAddStudents({ onAdd, triggerLabel, triggerClassName }: Props) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");

  const names = text
    .split("\n")
    .map((line) => line.replace(/^\s*\d+[).\-:]?\s*/, "").trim())
    .filter((line) => line.length > 0);

  function submit() {
    if (names.length === 0) return;
    onAdd(names);
    setText("");
    setOpen(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className={triggerClassName}>
          <Users className="ml-1 h-4 w-4" />
          {triggerLabel ?? "إضافة الطلاب دفعة واحدة"}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-serif text-xl">
            <ClipboardList className="h-5 w-5 text-teal-600" />
            إضافة الطلاب دفعة واحدة
          </DialogTitle>
          <DialogDescription>
            اكتب اسم كل طالب في سطر منفصل. يمكن ترقيم الأسطر وسيتم تجاهل الأرقام تلقائيًا.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          <Label htmlFor="bulk-names">أسماء الطلاب</Label>
          <Textarea
            id="bulk-names"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={"1. محمد أحمد\n2. علي حسن\n3. سارة خالد"}
            className="min-h-40 resize-y"
          />
          <p className="text-xs text-slate-500">
            {names.length > 0 ? `سيتم إضافة ${names.length} طالبًا.` : "لم يتم إدخال أي اسم بعد."}
          </p>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => setOpen(false)}>
            إلغاء
          </Button>
          <Button
            onClick={submit}
            disabled={names.length === 0}
            className="bg-teal-600 hover:bg-teal-700"
          >
            إضافة {names.length > 0 ? `(${names.length})` : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}