import { useMemo, useState } from "react";
import {
  CalendarCheck,
  CheckCircle2,
  Clock,
  FileSpreadsheet,
  FileText,
  Plus,
  Trash2,
  XCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import BulkAddStudents from "@/components/BulkAddStudents";
import ImportStudentsExcel from "@/components/ImportStudentsExcel";
import { useStore } from "@/lib/store";
import { exportExcel, exportPdf, type ExportPayload } from "@/lib/export";
import { SECTIONS, STAGES } from "@/lib/grades";

type Status = "present" | "absent" | "late";

type Row = {
  id: string;
  name: string;
  date: string;
  status: Status;
  note: string;
};

const STATUS_LABEL: Record<Status, string> = {
  present: "حاضر",
  absent: "غائب",
  late: "متأخر",
};

const STATUS_STYLE: Record<Status, string> = {
  present: "bg-emerald-100 text-emerald-800 hover:bg-emerald-100",
  absent: "bg-rose-100 text-rose-800 hover:bg-rose-100",
  late: "bg-amber-100 text-amber-800 hover:bg-amber-100",
};

const today = () => new Date().toISOString().slice(0, 10);

export default function AttendancePage() {
  const { settings } = useStore();
  const [stage, setStage] = useState<string>(settings.stage ?? STAGES.middle);
  const [level, setLevel] = useState<string>(settings.level ?? "");
  const [section, setSection] = useState<string>(settings.section ?? "أ");
  const [rows, setRows] = useState<Row[]>([
    { id: "a1", name: "", date: today(), status: "present", note: "" },
    { id: "a2", name: "", date: today(), status: "present", note: "" },
    { id: "a3", name: "", date: today(), status: "present", note: "" },
  ]);

  function addRow() {
    setRows((prev) => [
      ...prev,
      { id: `a${Date.now()}`, name: "", date: today(), status: "present", note: "" },
    ]);
  }

  function addMany(names: string[]) {
    setRows((prev) => {
      const cleaned = prev.filter((r) => r.name.trim().length > 0);
      const added = names.map((name, i) => ({
        id: `a${Date.now()}-${i}`,
        name,
        date: today(),
        status: "present" as Status,
        note: "",
      }));
      return [...cleaned, ...added];
    });
  }

  function removeRow(id: string) {
    setRows((prev) => prev.filter((r) => r.id !== id));
  }

  function update(id: string, patch: Partial<Row>) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  const stats = useMemo(() => {
    const present = rows.filter((r) => r.status === "present").length;
    const absent = rows.filter((r) => r.status === "absent").length;
    const late = rows.filter((r) => r.status === "late").length;
    const rate = rows.length ? Math.round((present / rows.length) * 100) : 0;
    return { present, absent, late, rate };
  }, [rows]);

  const payload: ExportPayload = useMemo(
    () => ({
      title: "سجلّي — الحضور والغياب",
      subtitle: `${stage} · ${level || "—"} · شعبة ${section}`,
      columns: [
        { key: "name", label: "اسم الطالب" },
        { key: "date", label: "التاريخ" },
        { key: "status", label: "الحالة" },
        { key: "note", label: "ملاحظات" },
      ],
      rows: rows.map((r) => ({
        name: r.name || "—",
        date: r.date,
        status: STATUS_LABEL[r.status],
        note: r.note || "—",
      })),
    }),
    [rows, stage, level, section],
  );

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-amber-100 bg-gradient-to-l from-amber-50 to-orange-50 p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500 text-white shadow-sm">
              <CalendarCheck className="h-6 w-6" />
            </div>
            <div>
              <h2 className="font-serif text-2xl font-bold text-slate-900">الحضور والغياب</h2>
              <p className="text-sm text-slate-600">
                {stage} · {level || "—"} · شعبة {section}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              onClick={() => exportPdf(payload)}
              className="bg-amber-500 hover:bg-amber-600"
            >
              <FileText className="ml-1 h-4 w-4" />
              تصدير PDF
            </Button>
            <Button
              variant="outline"
              onClick={() => exportExcel(payload)}
              className="border-amber-200 bg-white text-amber-700 hover:bg-amber-50"
            >
              <FileSpreadsheet className="ml-1 h-4 w-4" />
              تصدير Excel
            </Button>
          </div>
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-4 shadow-sm">
          <div className="flex items-center gap-2 text-emerald-700">
            <CheckCircle2 className="h-4 w-4" />
            <span className="text-xs font-medium">حاضر</span>
          </div>
          <p className="mt-2 text-2xl font-bold text-emerald-800">{stats.present}</p>
        </div>
        <div className="rounded-xl border border-rose-100 bg-rose-50 p-4 shadow-sm">
          <div className="flex items-center gap-2 text-rose-700">
            <XCircle className="h-4 w-4" />
            <span className="text-xs font-medium">غائب</span>
          </div>
          <p className="mt-2 text-2xl font-bold text-rose-800">{stats.absent}</p>
        </div>
        <div className="rounded-xl border border-amber-100 bg-amber-50 p-4 shadow-sm">
          <div className="flex items-center gap-2 text-amber-700">
            <Clock className="h-4 w-4" />
            <span className="text-xs font-medium">متأخر</span>
          </div>
          <p className="mt-2 text-2xl font-bold text-amber-800">{stats.late}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <p className="text-xs text-slate-500">نسبة الحضور</p>
          <p className="mt-2 text-2xl font-bold text-slate-800">{stats.rate}%</p>
        </div>
      </div>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">بيانات الصف</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-2">
              <Label>المرحلة</Label>
              <Select value={stage} onValueChange={setStage}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر المرحلة" />
                </SelectTrigger>
                <SelectContent>
                  {Object.values(STAGES).map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الصف</Label>
              <Input
                value={level}
                onChange={(e) => setLevel(e.target.value)}
                placeholder="مثال: الثاني المتوسط"
              />
            </div>
            <div className="space-y-2">
              <Label>الشعبة</Label>
              <Select value={section} onValueChange={setSection}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر الشعبة" />
                </SelectTrigger>
                <SelectContent>
                  {SECTIONS.map((sec) => (
                    <SelectItem key={sec} value={sec}>
                      شعبة {sec}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-2">
          <CardTitle className="text-lg">سجل الحضور والغياب</CardTitle>
          <div className="flex flex-wrap items-center gap-2">
            <ImportStudentsExcel
              onImport={addMany}
              triggerClassName="border-amber-200 text-amber-700 hover:bg-amber-50"
            />
            <BulkAddStudents
              onAdd={addMany}
              triggerClassName="border-amber-200 text-amber-700 hover:bg-amber-50"
            />
            <Button onClick={addRow} className="bg-amber-500 hover:bg-amber-600">
              <Plus className="ml-1 h-4 w-4" />
              إضافة طالب
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead className="text-right text-slate-700">اسم الطالب</TableHead>
                  <TableHead className="text-center text-slate-700">التاريخ</TableHead>
                  <TableHead className="text-center text-slate-700">الحالة</TableHead>
                  <TableHead className="text-right text-slate-700">ملاحظات</TableHead>
                  <TableHead className="text-center text-slate-700">إجراء</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id} className="hover:bg-amber-50/40">
                    <TableCell className="min-w-48">
                      <Input
                        value={r.name}
                        onChange={(e) => update(r.id, { name: e.target.value })}
                        placeholder="اسم الطالب"
                      />
                    </TableCell>
                    <TableCell className="text-center">
                      <Input
                        type="date"
                        value={r.date}
                        onChange={(e) => update(r.id, { date: e.target.value })}
                        className="mx-auto w-40"
                      />
                    </TableCell>
                    <TableCell className="text-center">
                      <Select
                        value={r.status}
                        onValueChange={(v) => update(r.id, { status: v as Status })}
                      >
                        <SelectTrigger className="mx-auto w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="present">حاضر</SelectItem>
                          <SelectItem value="absent">غائب</SelectItem>
                          <SelectItem value="late">متأخر</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="min-w-40">
                      <Input
                        value={r.note}
                        onChange={(e) => update(r.id, { note: e.target.value })}
                        placeholder="ملاحظة"
                      />
                    </TableCell>
                    <TableCell className="text-center">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeRow(r.id)}
                        className="text-slate-400 hover:text-rose-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {rows.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="py-10 text-center text-sm text-slate-500">
                      لا يوجد سجلات. اضغط «إضافة طالب» أو «إضافة الطلاب دفعة واحدة» أو
                      «استيراد الطلبة من الإكسل» للبدء.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
            <Badge className={STATUS_STYLE.present}>حاضر: {stats.present}</Badge>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                onClick={() => exportPdf(payload)}
                className="border-amber-200 text-amber-700 hover:bg-amber-50"
              >
                <FileText className="ml-1 h-4 w-4" />
                تصدير PDF
              </Button>
              <Button
                variant="outline"
                onClick={() => exportExcel(payload)}
                className="border-amber-200 text-amber-700 hover:bg-amber-50"
              >
                <FileSpreadsheet className="ml-1 h-4 w-4" />
                تصدير Excel
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}