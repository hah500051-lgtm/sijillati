import { useMemo, useState } from "react";
import {
  CalendarCheck,
  CalendarDays,
  FileText,
  TrendingUp,
  Award,
  ClipboardList,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { averagePercent, attendanceSummary, useStore } from "@/lib/store";
import { exportExcel, exportPdf, type ExportPayload } from "@/lib/export";

type ReportTab = "monthly" | "grades";

const TABS: { id: ReportTab; label: string; icon: typeof CalendarCheck }[] = [
  { id: "monthly", label: "الحضور والغياب الشهري", icon: CalendarDays },
  { id: "grades", label: "سجل الدرجات الشهري", icon: ClipboardList },
];

const STATUS_STYLE: Record<string, string> = {
  present: "bg-emerald-100 text-emerald-800 hover:bg-emerald-100",
  absent: "bg-rose-100 text-rose-800 hover:bg-rose-100",
  late: "bg-amber-100 text-amber-800 hover:bg-amber-100",
};

const AR_MONTHS = [
  "يناير",
  "فبراير",
  "مارس",
  "أبريل",
  "مايو",
  "يونيو",
  "يوليو",
  "أغسطس",
  "سبتمبر",
  "أكتوبر",
  "نوفمبر",
  "ديسمبر",
];

function monthKey(date: string) {
  return date.slice(0, 7);
}

function monthLabel(key: string) {
  const [y, m] = key.split("-");
  const idx = Number(m) - 1;
  return `${AR_MONTHS[idx] ?? m} ${y}`;
}

export default function ReportPage() {
  const { grades, attendance, settings } = useStore();
  const [tab, setTab] = useState<ReportTab>("monthly");

  const avg = averagePercent(grades);
  const att = attendanceSummary(attendance);
  const passed = avg >= settings.passMark;

  const monthlyRows = useMemo(() => {
    const map = new Map<
      string,
      { present: number; absent: number; late: number; total: number }
    >();
    attendance.forEach((r) => {
      const key = monthKey(r.date);
      const entry = map.get(key) ?? { present: 0, absent: 0, late: 0, total: 0 };
      entry[r.status] += 1;
      entry.total += 1;
      map.set(key, entry);
    });
    return Array.from(map.entries())
      .sort((a, b) => (a[0] < b[0] ? 1 : -1))
      .map(([key, v]) => ({
        key,
        label: monthLabel(key),
        ...v,
        rate: v.total ? Math.round(((v.present + v.late) / v.total) * 100) : 0,
      }));
  }, [attendance]);

  const gradeMonthlyRows = useMemo(() => {
    const map = new Map<string, { total: number; max: number; count: number }>();
    grades.forEach((g) => {
      const key = monthKey(g.date);
      const entry = map.get(key) ?? { total: 0, max: 0, count: 0 };
      entry.total += g.score;
      entry.max += g.max;
      entry.count += 1;
      map.set(key, entry);
    });
    return Array.from(map.entries())
      .sort((a, b) => (a[0] < b[0] ? 1 : -1))
      .map(([key, v]) => ({
        key,
        label: monthLabel(key),
        count: v.count,
        total: v.total,
        max: v.max,
        rate: v.max ? Math.round((v.total / v.max) * 100) : 0,
      }));
  }, [grades]);

  const payload: ExportPayload = useMemo(() => {
    if (tab === "monthly") {
      return {
        title: "سجلّي — الحضور والغياب الشهري",
        subtitle: `${settings.studentName} · ${settings.className}`,
        columns: [
          { key: "label", label: "الشهر" },
          { key: "present", label: "حاضر" },
          { key: "late", label: "متأخر" },
          { key: "absent", label: "غائب" },
          { key: "total", label: "المجموع" },
          { key: "rate", label: "نسبة الالتزام %" },
        ],
        rows: monthlyRows,
      };
    }
    return {
      title: "سجلّي — سجل الدرجات الشهري",
      subtitle: `${settings.studentName} · ${settings.className}`,
      columns: [
        { key: "label", label: "الشهر" },
        { key: "count", label: "عدد التقييمات" },
        { key: "total", label: "المجموع" },
        { key: "max", label: "الدرجة الكاملة" },
        { key: "rate", label: "النسبة %" },
      ],
      rows: gradeMonthlyRows,
    };
  }, [tab, monthlyRows, gradeMonthlyRows, settings]);

  return (
    <div className="space-y-6">
      <Card className="overflow-hidden border-slate-200 shadow-sm">
        <div className="bg-gradient-to-l from-teal-700 to-emerald-500 px-6 py-6 text-white">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-sm text-teal-50/90">التقرير الأكاديمي الشامل</p>
              <h2 className="mt-1 font-serif text-2xl font-bold">{settings.studentName}</h2>
              <p className="text-sm text-teal-50/90">
                {settings.className} · {settings.teacher}
              </p>
            </div>
            <div className="rounded-2xl bg-white/15 px-6 py-4 text-center backdrop-blur">
              <p className="text-xs text-teal-50/80">المعدل العام</p>
              <p className="text-3xl font-bold">{avg}%</p>
              <Badge
                className={
                  passed
                    ? "bg-emerald-200 text-emerald-900 hover:bg-emerald-200"
                    : "bg-rose-200 text-rose-900 hover:bg-rose-200"
                }
              >
                {passed ? "ناجح" : "يحتاج تحسين"}
              </Badge>
            </div>
          </div>
        </div>

        <CardContent className="grid gap-6 p-6 sm:grid-cols-3">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-50 text-teal-700">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm text-slate-500">عدد التقييمات</p>
              <p className="text-xl font-bold text-slate-900">{grades.length}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
              <CalendarCheck className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm text-slate-500">نسبة الالتزام</p>
              <p className="text-xl font-bold text-slate-900">{att.rate}%</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-50 text-amber-700">
              <Award className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm text-slate-500">أيام الغياب</p>
              <p className="text-xl font-bold text-slate-900">{att.absent}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <Button
                key={t.id}
                variant={active ? "default" : "outline"}
                onClick={() => setTab(t.id)}
                className={
                  active
                    ? "bg-teal-600 hover:bg-teal-700"
                    : "border-teal-200 text-teal-700 hover:bg-teal-50"
                }
              >
                <Icon className="ml-1 h-4 w-4" />
                {t.label}
              </Button>
            );
          })}
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => exportPdf(payload)}
            className="border-teal-200 text-teal-700 hover:bg-teal-50"
          >
            <FileText className="ml-1 h-4 w-4" />
            تصدير PDF
          </Button>
          <Button
            variant="outline"
            onClick={() => exportExcel(payload)}
            className="border-teal-200 text-teal-700 hover:bg-teal-50"
          >
            <FileText className="ml-1 h-4 w-4" />
            تصدير Excel
          </Button>
        </div>
      </div>

      {tab === "monthly" && (
        <Card className="border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <CalendarDays className="h-5 w-5 text-teal-600" />
              الحضور والغياب الشهري
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead className="text-right text-slate-700">الشهر</TableHead>
                    <TableHead className="text-center text-slate-700">حاضر</TableHead>
                    <TableHead className="text-center text-slate-700">متأخر</TableHead>
                    <TableHead className="text-center text-slate-700">غائب</TableHead>
                    <TableHead className="text-center text-slate-700">المجموع</TableHead>
                    <TableHead className="text-center text-slate-700">نسبة الالتزام</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {monthlyRows.map((m) => (
                    <TableRow key={m.key} className="hover:bg-teal-50/40">
                      <TableCell className="text-right font-medium text-slate-700">
                        {m.label}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={STATUS_STYLE.present}>{m.present}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={STATUS_STYLE.late}>{m.late}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={STATUS_STYLE.absent}>{m.absent}</Badge>
                      </TableCell>
                      <TableCell className="text-center text-slate-700">{m.total}</TableCell>
                      <TableCell className="text-center">
                        <div className="mx-auto flex w-32 items-center gap-2">
                          <Progress value={m.rate} className="h-2" />
                          <span className="text-xs text-slate-500">{m.rate}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {monthlyRows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="py-10 text-center text-sm text-slate-500">
                        لا توجد بيانات شهرية.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {tab === "grades" && (
        <Card className="border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ClipboardList className="h-5 w-5 text-teal-600" />
              سجل الدرجات الشهري
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead className="text-right text-slate-700">الشهر</TableHead>
                    <TableHead className="text-center text-slate-700">عدد التقييمات</TableHead>
                    <TableHead className="text-center text-slate-700">المجموع</TableHead>
                    <TableHead className="text-center text-slate-700">الدرجة الكاملة</TableHead>
                    <TableHead className="text-center text-slate-700">النسبة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {gradeMonthlyRows.map((m) => (
                    <TableRow key={m.key} className="hover:bg-teal-50/40">
                      <TableCell className="text-right font-medium text-slate-700">
                        {m.label}
                      </TableCell>
                      <TableCell className="text-center text-slate-700">{m.count}</TableCell>
                      <TableCell className="text-center text-slate-700">{m.total}</TableCell>
                      <TableCell className="text-center text-slate-700">{m.max}</TableCell>
                      <TableCell className="text-center">
                        <div className="mx-auto flex w-32 items-center gap-2">
                          <Progress value={m.rate} className="h-2" />
                          <span className="text-xs text-slate-500">{m.rate}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {gradeMonthlyRows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="py-10 text-center text-sm text-slate-500">
                        لا توجد درجات مسجلة.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}