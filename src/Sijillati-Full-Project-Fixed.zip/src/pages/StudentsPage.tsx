import { useState } from "react";
import { Users, Plus, Trash2, Phone } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { actions, useStore } from "@/lib/store";

export default function StudentsPage() {
  const { students } = useStore();
  const [name, setName] = useState("");
  const [className, setClassName] = useState("");
  const [phone, setPhone] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    actions.addStudent({
      name: name.trim(),
      className: className.trim() || "غير محدد",
      phone: phone.trim(),
    });
    setName("");
    setClassName("");
    setPhone("");
  }

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Plus className="h-5 w-5 text-teal-600" />
            إضافة طالب
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="s-name">اسم الطالب</Label>
              <Input id="s-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: عبدالله محمد" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="s-class">الصف</Label>
              <Input id="s-class" value={className} onChange={(e) => setClassName(e.target.value)} placeholder="الصف الثالث - أ" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="s-phone">رقم الجوال</Label>
              <Input id="s-phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="05xxxxxxxx" />
            </div>
            <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700">
              حفظ الطالب
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="border-slate-200 shadow-sm lg:col-span-2">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Users className="h-5 w-5 text-teal-600" />
            قائمة الطلاب
          </CardTitle>
          <Badge className="bg-teal-100 text-teal-800 hover:bg-teal-100">{students.length} طالب</Badge>
        </CardHeader>
        <CardContent className="space-y-3">
          {students.length === 0 && (
            <p className="py-10 text-center text-sm text-slate-500">لا يوجد طلاب. أضف أول طالب من النموذج.</p>
          )}
          {students.map((s) => (
            <div
              key={s.id}
              className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50/60 px-4 py-3"
            >
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-teal-100 text-teal-700">
                    {s.name.slice(0, 1)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-slate-800">{s.name}</p>
                  <p className="text-xs text-slate-500">{s.className}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {s.phone && (
                  <span className="hidden items-center gap-1 text-xs text-slate-500 sm:flex">
                    <Phone className="h-3.5 w-3.5" />
                    {s.phone}
                  </span>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => actions.removeStudent(s.id)}
                  className="text-slate-400 hover:text-rose-600"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}