import { useState } from "react";
import { Save, Settings as SettingsIcon, UserRound } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { actions, useStore } from "@/lib/store";
import { LEVELS, SECTIONS, STAGES, type StageKey } from "@/lib/grades";

export default function SettingsPage() {
  const { settings } = useStore();
  const [stage, setStage] = useState<StageKey>(settings.stageKey ?? "middle");
  const [level, setLevel] = useState(settings.level ?? LEVELS.middle[0]);
  const [section, setSection] = useState(settings.section ?? "أ");
  const [studentName, setStudentName] = useState(settings.studentName ?? "");
  const [saved, setSaved] = useState(false);

  function changeStage(next: StageKey) {
    setStage(next);
    setLevel(LEVELS[next][0]);
  }

  function save() {
    actions.updateSettings({
      stageKey: stage,
      stage: STAGES[stage],
      level,
      section,
      studentName,
    });
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-slate-200 bg-gradient-to-l from-slate-100 to-white p-6 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-800 text-white shadow-sm">
            <SettingsIcon className="h-6 w-6" />
          </div>
          <div>
            <h2 className="font-serif text-2xl font-bold text-slate-900">الإعدادات</h2>
            <p className="text-sm text-slate-600">بيانات الطالب والمرحلة الدراسية</p>
          </div>
        </div>
      </section>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">بيانات الطالب</CardTitle>
          <CardDescription>تُستخدم هذه البيانات في التقارير وعمليات التصدير</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="settings-student">اسم الطالب</Label>
              <div className="relative">
                <UserRound className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <Input
                  id="settings-student"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="اكتب اسم الطالب"
                  className="pr-9"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>المرحلة</Label>
              <Select value={stage} onValueChange={(v) => changeStage(v as StageKey)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر المرحلة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="middle">{STAGES.middle}</SelectItem>
                  <SelectItem value="prep">{STAGES.prep}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الصف</Label>
              <Select value={level} onValueChange={setLevel}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر الصف" />
                </SelectTrigger>
                <SelectContent>
                  {LEVELS[stage].map((lvl) => (
                    <SelectItem key={lvl} value={lvl}>
                      {lvl}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الشعبة</Label>
              <Select value={section} onValueChange={setSection}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر الشعبة" />
                </SelectTrigger>
                <SelectContent>
                  {SECTIONS.map((sec) => (
                    <SelectItem key={sec} value={sec}>
                      شعبة {sec}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <Button onClick={save} className="bg-slate-800 hover:bg-slate-900">
              <Save className="ml-1 h-4 w-4" />
              حفظ الإعدادات
            </Button>
            {saved && <span className="text-sm text-emerald-600">تم الحفظ بنجاح</span>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}