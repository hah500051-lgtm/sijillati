import { useMemo } from "react";
import {
  ArrowLeft,
  BookOpen,
  CalendarCheck,
  ClipboardList,
  FileText,
  GraduationCap,
  Settings as SettingsIcon,
  TrendingUp,
  Users,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/store";
import { STAGES, trackLabel } from "@/lib/grades";

type Props = { onNavigate: (key: string) => void };

export default function HomePage({ onNavigate }: Props) {
  const { settings, grades, attendance } = useStore();

  const stats = useMemo(() => {
    const total = grades.length;
    const avg = total
      ? Math.round(grades.reduce((acc, g) => acc + (g.score / g.max) * 100, 0) / total)
      : 0;
    const present = attendance.filter((a) => a.status === "present").length;
    const rate = attendance.length ? Math.round((present / attendance.length) * 100) : 0;
    return { total, avg, rate, records: attendance.length };
  }, [grades, attendance]);

  const tiles = [
    {
      key: "grades",
      title: "درجات اللغة العربية",
      desc: "رصد درجات الشهر الأول والثاني وحساب سعي الفصل الأول",
      icon: BookOpen,
      tint: "bg-teal-50 text-teal-700 border-teal-100",
      chip: "bg-teal-600",
    },
    {
      key: "attendance",
      title: "الحضور والغياب",
      desc: "تسجيل الحضور والغياب والتأخر مع الملاحظات اليومية",
      icon: CalendarCheck,
      tint: "bg-amber-50 text-amber-700 border-amber-100",
      chip: "bg-amber-500",
    },
    {
      key: "report",
      title: "التقرير",
      desc: "ملخص شامل للدرجات ونسب الحضور مع التصدير",
      icon: FileText,
      tint: "bg-indigo-50 text-indigo-700 border-indigo-100",
      chip: "bg-indigo-600",
    },
    {
      key: "settings",
      title: "الإعدادات",
      desc: "بيانات الطالب والمرحلة الدراسية والشعبة",
      icon: SettingsIcon,
      tint: "bg-slate-100 text-slate-700 border-slate-200",
      chip: "bg-slate-800",
    },
  ];

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-2xl border border-teal-100 bg-gradient-to-l from-teal-600 to-emerald-500 p-6 text-white shadow-md sm:p-8">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="max-w-xl space-y-3">
            <Badge className="bg-white/20 text-white hover:bg-white/20">
              الفصل الدراسي الأول
            </Badge>
            <h1 className="font-serif text-3xl font-bold leading-tight sm:text-4xl">
              سجلّي
            </h1>
            <p className="text-sm text-teal-50 sm:text-base">
              سجل متكامل لمتابعة درجات اللغة العربية والحضور والغياب، مع تقارير جاهزة
              للتصدير بصيغة PDF و Excel.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              <Button
                onClick={() => onNavigate("grades")}
                className="bg-white text-teal-700 hover:bg-teal-50"
              >
                <BookOpen className="ml-1 h-4 w-4" />
                رصد الدرجات
              </Button>
              <Button
                variant="outline"
                onClick={() => onNavigate("attendance")}
                className="border-white/40 bg-transparent text-white hover:bg-white/10 hover:text-white"
              >
                <CalendarCheck className="ml-1 h-4 w-4" />
                تسجيل الحضور
              </Button>
            </div>
          </div>

          <div className="w-full max-w-xs rounded-xl border border-white/20 bg-white/10 p-4 backdrop-blur-sm">
            <div className="flex items-center gap-2 text-teal-50">
              <GraduationCap className="h-5 w-5" />
              <span className="text-sm font-medium">بيانات الطالب</span>
            </div>
            <p className="mt-3 font-serif text-xl font-bold">
              {settings.studentName || "لم يُحدد الاسم"}
            </p>
            <p className="mt-1 text-sm text-teal-50">
              {settings.stage || STAGES.middle}
              {settings.level ? ` · ${settings.level}` : ""}
              {settings.section ? ` · شعبة ${settings.section}` : ""}
            </p>
            <p className="mt-2 text-xs text-teal-100">
              {settings.level ? trackLabel(settings.stageKey ?? "middle", settings.level) : "—"}
            </p>
          </div>
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-teal-100 bg-teal-50 p-5 shadow-sm">
          <div className="flex items-center gap-2 text-teal-700">
            <ClipboardList className="h-4 w-4" />
            <span className="text-xs font-medium">عدد السجلات</span>
          </div>
          <p className="mt-2 text-3xl font-bold text-teal-800">{stats.total}</p>
          <p className="mt-1 text-xs text-teal-700">سجلات درجات محفوظة</p>
        </div>
        <div className="rounded-xl border border-indigo-100 bg-indigo-50 p-5 shadow-sm">
          <div className="flex items-center gap-2 text-indigo-700">
            <TrendingUp className="h-4 w-4" />
            <span className="text-xs font-medium">متوسط الدرجات</span>
          </div>
          <p className="mt-2 text-3xl font-bold text-indigo-800">{stats.avg}%</p>
          <p className="mt-1 text-xs text-indigo-700">نسبة من الدرجة الكاملة</p>
        </div>
        <div className="rounded-xl border border-amber-100 bg-amber-50 p-5 shadow-sm">
          <div className="flex items-center gap-2 text-amber-700">
            <Users className="h-4 w-4" />
            <span className="text-xs font-medium">نسبة الحضور</span>
          </div>
          <p className="mt-2 text-3xl font-bold text-amber-800">{stats.rate}%</p>
          <p className="mt-1 text-xs text-amber-700">{stats.records} سجل حضور</p>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {tiles.map((t) => {
          const Icon = t.icon;
          return (
            <Card
              key={t.key}
              className={`cursor-pointer border shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${t.tint}`}
              onClick={() => onNavigate(t.key)}
            >
              <CardHeader>
                <div className="flex items-start justify-between gap-3">
                  <div className={`flex h-11 w-11 items-center justify-center rounded-xl text-white shadow-sm ${t.chip}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <ArrowLeft className="h-4 w-4 opacity-50" />
                </div>
                <CardTitle className="mt-3 text-lg text-slate-900">{t.title}</CardTitle>
                <CardDescription className="text-slate-600">{t.desc}</CardDescription>
              </CardHeader>
              <CardContent>
                <span className="text-sm font-medium">فتح القسم</span>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}