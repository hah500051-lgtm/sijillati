import { useMemo, useState } from "react";
import {
  BookOpen,
  FileSpreadsheet,
  FileText,
  Plus,
  Trash2,
  UserRound,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import BulkAddStudents from "@/components/BulkAddStudents";
import ImportStudentsExcel from "@/components/ImportStudentsExcel";
import { actions, useStore } from "@/lib/store";
import { exportExcel, exportPdf, type ExportPayload } from "@/lib/export";
import {
  LEVELS,
  MONTHS,
  SECTIONS,
  STAGES,
  subjectsFor,
  trackLabel,
  type StageKey,
} from "@/lib/grades";

type MonthScores = Record<string, string>;
type Row = { id: string; name: string; months: Record<string, MonthScores> };

const emptyMonths = (): Record<string, MonthScores> => ({ m1: {}, m2: {} });

export default function GradesPage() {
  const { settings } = useStore();
  const [stage, setStage] = useState<StageKey>("middle");
  const [level, setLevel] = useState(LEVELS.middle[0]);
  const [section, setSection] = useState("أ");
  const [studentName, setStudentName] = useState(settings.studentName ?? "");
  const [rows, setRows] = useState<Row[]>([
    { id: "r1", name: "", months: emptyMonths() },
    { id: "r2", name: "", months: emptyMonths() },
    { id: "r3", name: "", months: emptyMonths() },
  ]);

  const MAX = subjectsFor(stage, level);
  const KEYS = Object.keys(MAX);

  function changeStage(next: StageKey) {
    setStage(next);
    setLevel(LEVELS[next][0]);
  }

  function addRow() {
    setRows((prev) => [...prev, { id: `r${Date.now()}`, name: "", months: emptyMonths() }]);
  }

  function addMany(names: string[]) {
    setRows((prev) => {
      const cleaned = prev.filter((r) => r.name.trim().length > 0);
      const added = names.map((name, i) => ({
        id: `r${Date.now()}-${i}`,
        name,
        months: emptyMonths(),
      }));
      return [...cleaned, ...added];
    });
  }

  function removeRow(id: string) {
    setRows((prev) => prev.filter((r) => r.id !== id));
  }

  function setName(id: string, name: string) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, name } : r)));
  }

  function setScore(id: string, monthKey: string, subject: string, value: string) {
    setRows((prev) =>
      prev.map((r) =>
        r.id === id
          ? {
              ...r,
              months: {
                ...r.months,
                [monthKey]: { ...r.months[monthKey], [subject]: value },
              },
            }
          : r,
      ),
    );
  }

  const computed = useMemo(
    () =>
      rows.map((r) => {
        const monthTotals: Record<string, number> = {};
        MONTHS.forEach((m) => {
          monthTotals[m.key] = KEYS.reduce((acc, k) => {
            const v = Number(r.months[m.key]?.[k]);
            return acc + (Number.isFinite(v) ? v : 0);
          }, 0);
        });
        const sum = monthTotals.m1 + monthTotals.m2;
        const divided = Math.round((sum / 2) * 100) / 100;
        const saay = Math.round(divided);
        return { id: r.id, monthTotals, sum, divided, saay };
      }),
    [rows, KEYS],
  );

  const payload: ExportPayload = useMemo(() => {
    const columns = [
      { key: "name", label: "اسم الطالب" },
      ...MONTHS.flatMap((m) =>
        KEYS.map((k) => ({ key: `${m.key}-${k}`, label: `${m.label} — ${k} (${MAX[k]})` })),
      ),
      { key: "m1Total", label: "مجموع الشهر الأول" },
      { key: "m2Total", label: "مجموع الشهر الثاني" },
      { key: "sum", label: "المجموع" },
      { key: "divided", label: "المجموع ÷ 2" },
      { key: "saay", label: "سعي الفصل الأول" },
    ];

    const data = rows.map((r) => {
      const info = computed.find((c) => c.id === r.id);
      const base: Record<string, string | number> = {
        name: r.name || "—",
        m1Total: info?.monthTotals.m1 ?? 0,
        m2Total: info?.monthTotals.m2 ?? 0,
        sum: info?.sum ?? 0,
        divided: info?.divided ?? 0,
        saay: info?.saay ?? 0,
      };
      MONTHS.forEach((m) => {
        KEYS.forEach((k) => {
          base[`${m.key}-${k}`] = r.months[m.key]?.[k] ?? "";
        });
      });
      return base;
    });

    return {
      title: "سجلّي — درجات اللغة العربية",
      subtitle: `${studentName || "—"} · ${STAGES[stage]} · ${level} · شعبة ${section} · ${trackLabel(stage, level)}`,
      columns,
      rows: data,
    };
  }, [rows, computed, KEYS, MAX, studentName, stage, level, section]);

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-teal-100 bg-gradient-to-l from-teal-50 to-emerald-50 p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-600 text-white shadow-sm">
              <BookOpen className="h-6 w-6" />
            </div>
            <div>
              <h2 className="font-serif text-2xl font-bold text-slate-900">درجات اللغة العربية</h2>
              <p className="text-sm text-slate-600">
                {studentName || "—"} · {STAGES[stage]} · {level} · شعبة {section}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge className="bg-teal-100 text-teal-800 hover:bg-teal-100">
              الفصل الأول — الشهر الأول والثاني · {trackLabel(stage, level)}
            </Badge>
            <Button
              onClick={() => exportPdf(payload)}
              className="bg-teal-600 hover:bg-teal-700"
            >
              <FileText className="ml-1 h-4 w-4" />
              تصدير PDF
            </Button>
            <Button
              variant="outline"
              onClick={() => exportExcel(payload)}
              className="border-teal-200 bg-white text-teal-700 hover:bg-teal-50"
            >
              <FileSpreadsheet className="ml-1 h-4 w-4" />
              تصدير Excel
            </Button>
          </div>
        </div>
      </section>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">بيانات الطالب والصف</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="student-name">اسم الطالب</Label>
              <div className="relative">
                <UserRound className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <Input
                  id="student-name"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="اكتب اسم الطالب"
                  className="pr-9"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>المرحلة</Label>
              <Select value={stage} onValueChange={(v) => changeStage(v as StageKey)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر المرحلة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="middle">{STAGES.middle}</SelectItem>
                  <SelectItem value="prep">{STAGES.prep}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الصف</Label>
              <Select value={level} onValueChange={setLevel}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر الصف" />
                </SelectTrigger>
                <SelectContent>
                  {LEVELS[stage].map((lvl) => (
                    <SelectItem key={lvl} value={lvl}>
                      {lvl}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الشعبة</Label>
              <Select value={section} onValueChange={setSection}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر الشعبة" />
                </SelectTrigger>
                <SelectContent>
                  {SECTIONS.map((sec) => (
                    <SelectItem key={sec} value={sec}>
                      شعبة {sec}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-2">
          <CardTitle className="text-lg">
            جدول درجة الشهر الأول والثاني — الفصل الأول ({trackLabel(stage, level)})
          </CardTitle>
          <div className="flex flex-wrap items-center gap-2">
            <ImportStudentsExcel
              onImport={addMany}
              triggerClassName="border-teal-200 text-teal-700 hover:bg-teal-50"
            />
            <BulkAddStudents
              onAdd={addMany}
              triggerClassName="border-teal-200 text-teal-700 hover:bg-teal-50"
            />
            <Button onClick={addRow} className="bg-teal-600 hover:bg-teal-700">
              <Plus className="ml-1 h-4 w-4" />
              إضافة طالب
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead rowSpan={2} className="text-right text-slate-700">
                    اسم الطالب
                  </TableHead>
                  {MONTHS.map((m) => (
                    <TableHead
                      key={m.key}
                      colSpan={KEYS.length}
                      className="border-r border-slate-200 text-center text-slate-700"
                    >
                      {m.label}
                    </TableHead>
                  ))}
                  <TableHead
                    rowSpan={2}
                    className="border-r border-slate-200 text-center text-slate-700"
                  >
                    <span className="block">المجموع</span>
                    <span className="block text-xs font-normal text-slate-400">(الشهرين)</span>
                  </TableHead>
                  <TableHead
                    rowSpan={2}
                    className="border-r border-slate-200 text-center text-slate-700"
                  >
                    <span className="block">المجموع ÷ 2</span>
                    <span className="block text-xs font-normal text-slate-400">(التقسيم)</span>
                  </TableHead>
                  <TableHead
                    rowSpan={2}
                    className="border-r border-slate-200 text-center text-slate-700"
                  >
                    <span className="block">سعي الفصل الأول</span>
                    <span className="block text-xs font-normal text-slate-400">(100)</span>
                  </TableHead>
                  <TableHead rowSpan={2} className="text-center text-slate-700">
                    إجراء
                  </TableHead>
                </TableRow>
                <TableRow className="bg-slate-50">
                  {MONTHS.map((m) =>
                    KEYS.map((k) => (
                      <TableHead
                        key={`${m.key}-${k}`}
                        className="text-center text-xs font-normal text-slate-500"
                      >
                        <span className="block">{k}</span>
                        <span className="block text-slate-400">({MAX[k]})</span>
                      </TableHead>
                    )),
                  )}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => {
                  const info = computed.find((c) => c.id === r.id);
                  return (
                    <TableRow key={r.id} className="hover:bg-teal-50/40">
                      <TableCell className="min-w-48">
                        <Input
                          value={r.name}
                          onChange={(e) => setName(r.id, e.target.value)}
                          placeholder="اسم الطالب"
                        />
                      </TableCell>
                      {MONTHS.map((m) =>
                        KEYS.map((k) => (
                          <TableCell key={`${m.key}-${k}`} className="text-center">
                            <Input
                              type="number"
                              min={0}
                              max={MAX[k]}
                              value={r.months[m.key]?.[k] ?? ""}
                              onChange={(e) => setScore(r.id, m.key, k, e.target.value)}
                              className="mx-auto w-16 text-center"
                              placeholder="0"
                            />
                          </TableCell>
                        )),
                      )}
                      <TableCell className="border-r border-slate-200 text-center">
                        <Badge className="bg-slate-100 text-slate-700 hover:bg-slate-100">
                          {info?.sum ?? 0}
                        </Badge>
                      </TableCell>
                      <TableCell className="border-r border-slate-200 text-center">
                        <Badge className="bg-indigo-100 text-indigo-800 hover:bg-indigo-100">
                          {info?.divided ?? 0}
                        </Badge>
                      </TableCell>
                      <TableCell className="border-r border-slate-200 text-center">
                        <Badge className="bg-teal-100 text-teal-800 hover:bg-teal-100">
                          {info?.saay ?? 0}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeRow(r.id)}
                          className="text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {rows.length === 0 && (
                  <TableRow>
                    <TableCell
                      colSpan={KEYS.length * MONTHS.length + 5}
                      className="py-10 text-center text-sm text-slate-500"
                    >
                      لا يوجد طلاب في الجدول. اضغط «إضافة طالب» أو «إضافة الطلاب دفعة واحدة» أو
                      «استيراد الطلبة من الإكسل» للبدء.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="mt-4 flex flex-wrap justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => exportPdf(payload)}
              className="border-teal-200 text-teal-700 hover:bg-teal-50"
            >
              <FileText className="ml-1 h-4 w-4" />
              تصدير PDF
            </Button>
            <Button
              variant="outline"
              onClick={() => exportExcel(payload)}
              className="border-teal-200 text-teal-700 hover:bg-teal-50"
            >
              <FileSpreadsheet className="ml-1 h-4 w-4" />
              تصدير Excel
            </Button>
            <Button
              onClick={() =>
                actions.addGrade({
                  title: `${studentName || "طالب"} · ${STAGES[stage]} · ${level} — الفصل الأول`,
                  score: 0,
                  max: 100,
                  date: new Date().toISOString().slice(0, 10),
                })
              }
              className="bg-teal-600 hover:bg-teal-700"
            >
              حفظ الجدول
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}