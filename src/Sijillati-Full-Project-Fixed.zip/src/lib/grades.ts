export type SubjectMax = Record<string, number>;

export const STAGES = {
  middle: "المرحلة المتوسطة",
  prep: "المرحلة الإعدادية",
} as const;

export type StageKey = keyof typeof STAGES;

export const LEVELS: Record<StageKey, string[]> = {
  middle: ["الأول المتوسط", "الثاني المتوسط", "الثالث المتوسط"],
  prep: [
    "الرابع العلمي",
    "الخامس العلمي",
    "السادس العلمي",
    "الرابع الأدبي",
    "الخامس الأدبي",
    "السادس الأدبي",
  ],
};

export const SECTIONS = ["أ", "ب", "ج", "د"];

export const MIDDLE_MAX: SubjectMax = {
  القواعد: 30,
  الإملاء: 15,
  الإنشاء: 25,
  النصوص: 20,
  المطالعة: 10,
  اليومي: 100,
};

export const SCIENTIFIC_MAX: SubjectMax = {
  القواعد: 35,
  الأدب: 30,
  الإنشاء: 25,
  المطالعة: 10,
};

export const LITERARY_MAX: SubjectMax = {
  القواعد: 25,
  الأدب: 25,
  الإنشاء: 25,
  "البلاغة والنقد": 15,
  المطالعة: 10,
};

export function isScientific(level: string) {
  return level.includes("العلمي");
}

export function isLiterary(level: string) {
  return level.includes("الأدبي");
}

export function subjectsFor(stage: StageKey, level: string): SubjectMax {
  if (stage === "middle") return MIDDLE_MAX;
  return isScientific(level) ? SCIENTIFIC_MAX : LITERARY_MAX;
}

export function trackLabel(stage: StageKey, level: string) {
  if (stage === "middle") return "المرحلة المتوسطة";
  return isScientific(level) ? "الفرع العلمي" : "الفرع الأدبي";
}

export const MONTHS = [
  { key: "m1", label: "الشهر الأول" },
  { key: "m2", label: "الشهر الثاني" },
] as const;