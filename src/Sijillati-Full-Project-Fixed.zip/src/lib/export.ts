export type ExportColumn = { key: string; label: string };

export type ExportPayload = {
  title: string;
  subtitle?: string;
  columns: ExportColumn[];
  rows: Record<string, string | number>[];
};

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function stamp() {
  return new Date().toISOString().slice(0, 10);
}

export function exportExcel(payload: ExportPayload) {
  const esc = (v: string | number) =>
    String(v ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

  const head = payload.columns.map((c) => `<th>${esc(c.label)}</th>`).join("");
  const body = payload.rows
    .map(
      (r) =>
        `<tr>${payload.columns.map((c) => `<td>${esc(r[c.key])}</td>`).join("")}</tr>`,
    )
    .join("");

  const html = `<html dir="rtl"><head><meta charset="utf-8" /></head><body>
    <h2>${esc(payload.title)}</h2>
    ${payload.subtitle ? `<p>${esc(payload.subtitle)}</p>` : ""}
    <table border="1" cellspacing="0" cellpadding="6">
      <thead><tr>${head}</tr></thead>
      <tbody>${body}</tbody>
    </table>
  </body></html>`;

  download(
    new Blob(["\ufeff", html], { type: "application/vnd.ms-excel;charset=utf-8" }),
    `${payload.title || "export"}-${stamp()}.xls`,
  );
}

export function exportPdf(payload: ExportPayload) {
  const esc = (v: string | number) =>
    String(v ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

  const head = payload.columns.map((c) => `<th>${esc(c.label)}</th>`).join("");
  const body = payload.rows
    .map(
      (r) =>
        `<tr>${payload.columns.map((c) => `<td>${esc(r[c.key])}</td>`).join("")}</tr>`,
    )
    .join("");

  const html = `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8" />
    <title>${esc(payload.title)}</title>
    <style>
      * { box-sizing: border-box; }
      body { font-family: "Segoe UI", Tahoma, sans-serif; padding: 28px; color: #0f172a; }
      h1 { font-size: 20px; margin: 0 0 6px; color: #0f766e; }
      p.sub { margin: 0 0 18px; color: #475569; font-size: 13px; }
      table { width: 100%; border-collapse: collapse; font-size: 12px; }
      th, td { border: 1px solid #cbd5e1; padding: 6px 8px; text-align: center; }
      th { background: #ccfbf1; color: #115e59; }
      tr:nth-child(even) td { background: #f8fafc; }
      @media print { body { padding: 0; } }
    </style></head><body>
    <h1>${esc(payload.title)}</h1>
    ${payload.subtitle ? `<p class="sub">${esc(payload.subtitle)}</p>` : ""}
    <table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>
    <script>window.onload = function () { window.print(); };</script>
  </body></html>`;

  const win = window.open("", "_blank");
  if (!win) return;
  win.document.write(html);
  win.document.close();
}