import { useSyncExternalStore } from "react";

export type Grade = {
  id: string;
  title: string;
  score: number;
  max: number;
  date: string;
};

export type AttendanceStatus = "present" | "absent" | "late";

export type AttendanceRecord = {
  id: string;
  date: string;
  status: AttendanceStatus;
};

export type Student = {
  id: string;
  name: string;
  className: string;
  phone: string;
};

export type Settings = {
  studentName: string;
  className: string;
  teacher: string;
  passMark: number;
};

export type AppState = {
  grades: Grade[];
  attendance: AttendanceRecord[];
  students: Student[];
  settings: Settings;
};

const STORAGE_KEY = "sijilli-state-v2";

const defaultState: AppState = {
  grades: [
    { id: "g1", title: "اختبار النحو", score: 18, max: 20, date: "2024-09-12" },
    { id: "g2", title: "الإملاء", score: 14, max: 15, date: "2024-09-20" },
    { id: "g3", title: "التعبير الكتابي", score: 22, max: 30, date: "2024-10-02" },
    { id: "g4", title: "قراءة جهرية", score: 9, max: 10, date: "2024-10-15" },
  ],
  attendance: [
    { id: "a1", date: "2024-10-01", status: "present" },
    { id: "a2", date: "2024-10-02", status: "present" },
    { id: "a3", date: "2024-10-03", status: "late" },
    { id: "a4", date: "2024-10-06", status: "absent" },
    { id: "a5", date: "2024-10-07", status: "present" },
  ],
  students: [
    { id: "s1", name: "عبدالله محمد", className: "الصف الثالث - أ", phone: "0500000001" },
    { id: "s2", name: "ريم خالد", className: "الصف الثالث - أ", phone: "0500000002" },
    { id: "s3", name: "يوسف سعد", className: "الصف الثالث - ب", phone: "0500000003" },
  ],
  settings: {
    studentName: "عبدالله محمد",
    className: "الصف الثالث - أ",
    teacher: "أ. سارة العتيبي",
    passMark: 50,
  },
};

function load(): AppState {
  if (typeof window === "undefined") return defaultState;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState;
    const parsed = JSON.parse(raw) as Partial<AppState>;
    return {
      grades: parsed.grades ?? defaultState.grades,
      attendance: parsed.attendance ?? defaultState.attendance,
      students: parsed.students ?? defaultState.students,
      settings: { ...defaultState.settings, ...(parsed.settings ?? {}) },
    };
  } catch {
    return defaultState;
  }
}

let state: AppState = load();
const listeners = new Set<() => void>();

function emit() {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function getSnapshot() {
  return state;
}

export function useStore() {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
}

export const actions = {
  addGrade(g: Omit<Grade, "id">) {
    state = { ...state, grades: [...state.grades, { ...g, id: crypto.randomUUID() }] };
    emit();
  },
  removeGrade(id: string) {
    state = { ...state, grades: state.grades.filter((g) => g.id !== id) };
    emit();
  },
  addAttendance(date: string, status: AttendanceStatus) {
    state = {
      ...state,
      attendance: [...state.attendance, { id: crypto.randomUUID(), date, status }],
    };
    emit();
  },
  removeAttendance(id: string) {
    state = { ...state, attendance: state.attendance.filter((a) => a.id !== id) };
    emit();
  },
  addStudent(s: Omit<Student, "id">) {
    state = { ...state, students: [...state.students, { ...s, id: crypto.randomUUID() }] };
    emit();
  },
  removeStudent(id: string) {
    state = { ...state, students: state.students.filter((s) => s.id !== id) };
    emit();
  },
  updateSettings(patch: Partial<Settings>) {
    state = { ...state, settings: { ...state.settings, ...patch } };
    emit();
  },
  reset() {
    state = defaultState;
    emit();
  },
};

export function percent(score: number, max: number) {
  if (max <= 0) return 0;
  return Math.round((score / max) * 100);
}

export function averagePercent(grades: Grade[]) {
  if (grades.length === 0) return 0;
  const total = grades.reduce((acc, g) => acc + percent(g.score, g.max), 0);
  return Math.round(total / grades.length);
}

export function attendanceSummary(records: AttendanceRecord[]) {
  const present = records.filter((r) => r.status === "present").length;
  const absent = records.filter((r) => r.status === "absent").length;
  const late = records.filter((r) => r.status === "late").length;
  const total = records.length;
  const rate = total === 0 ? 0 : Math.round(((present + late) / total) * 100);
  return { present, absent, late, total, rate };
}